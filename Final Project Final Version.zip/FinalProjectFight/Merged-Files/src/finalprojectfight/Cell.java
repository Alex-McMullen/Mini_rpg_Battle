package finalprojectfight;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Insets;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;


/**
 *
 * @author nicho
 */
public class Cell {
    public static final Color WALL_COLOR = Color.BLACK;
    public static final Color EMPTY_COLOR = Color.GRAY;
    public static final Color DOOR_COLOR = Color.ORANGE;
    public static final Color CHEST_COLOR = Color.RED;
    public static final Icon WallIcon = new ImageIcon("src\\images\\brickwall.jpeg");
     public static final Icon ChestIcon = new ImageIcon("src\\images\\chest.jpg");
    public static final Icon FloorIcon = new ImageIcon("src\\images\\dungeonfloor.jpg");
    public static final Icon KnightIcon = new ImageIcon("src\\images\\knight2.jpg");


    private JButton button;
    private boolean occupied;
    private String cellType;//indicating whether the cell is a wall or if free for people to be on.
    private int row;
    private int col;
    
     
    private Character currentCharacter;
    
    
    public Cell(int rr, int cc, String thisCellType)
    {
        row = rr;
        col = cc;
        occupied = false;
        cellType = thisCellType;
        button = new JButton();
        button.setPreferredSize(new Dimension(Map.CELL_SIZE,Map.CELL_SIZE));
        button.setMargin(new Insets(0,0,0,0));
        if(cellType == "Wall")
        {
            button.setIcon(WallIcon);
        }
        else if (cellType == "Door"){
            button.setBackground(DOOR_COLOR);
        }
        else if (cellType == "Chest"){
            button.setIcon(ChestIcon);
        }
        else
        {
            button.setIcon(FloorIcon);
        }
        
        
        
    }
    
    public JButton getButton() {
        return button;
    }

    public void addCharacter(Character character) {
        currentCharacter= character;
        occupied = true;
        button.setText("Test");
        button.setIcon(KnightIcon);
       
    }
    
    public void removeCharacter()
    {
        currentCharacter= null;
        occupied = false;
        button.setIcon(FloorIcon);
        button.setText("");
    }

   public int getRow() {
        return row;
    }

    /**
     * Accessor method
     */
    public int getCol() {
        return col;
    }
    /*
    public boolean isWallCell() {
        return isWallCell;
    }
    */
    
    public String cellType(){
        return cellType;
    }

   
}

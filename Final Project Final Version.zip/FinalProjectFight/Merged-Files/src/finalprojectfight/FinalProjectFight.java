package finalprojectfight;

/**
 *
 * @author Alex McMullen
 */
public class FinalProjectFight 
{
    
    public static Double[] hi;
    public static Hero hero = new Knight(1,1,2,3,4,5,6,hi,false,false,"Healthy",0,"boo");
    public static Enemy enemy = new LizardMan(1,1,2,3,4,5,6,hi,false,false,"Healthy",0,"boo");
    public static String ability1Name = "";
    public static String ability2Name = "";
    public static String ability3Name = "";
    public static String healingName = "";
    
    public static void main(String[] args) 
    {
        
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            public void run() 
            {
                new HeroSelection().setVisible(true);
            }
        });
        
        
    }
    
    
}

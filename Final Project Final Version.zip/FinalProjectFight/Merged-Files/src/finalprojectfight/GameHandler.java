package finalprojectfight;

/**
 *
 * @author nicho
 */
public class GameHandler {
    public static Map map1;

    public static void GameHandle(){
        map1 = new Map(Map.map1);
       
        map1.initializeMap(1);
        
        map1.showMap();
    }
    
    public static void EnteredDoor(int column){
        map1.closeMap();
        
        map1 = new Map(Map.map1);

        map1.initializeMap(column);
        
        map1.showMap();
        
    }
}

package finalprojectfight;

/**
 *
 * @author Alex McMullen
 */
public class Hero extends Creature
{
    // CONSTRUCTORS
    
    /**
     * Empty Constructor
     */
    public Hero()
    {
        
    }
    
    /**
     * Simple Hero constructor that only has a max health and its current health
     * @param maxHP the maximum health the Hero can have
     * @param currentHP the current health of the Hero
     */
    public Hero(int maxHP, int currentHP)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
    }
    
    /**
     * Slightly more advanced constructor that contains the Hero's max health, current health, strength, and defense
     * @param maxHP the maximum health the Hero can have
     * @param currentHP the current health of the Hero
     * @param str how physically strong the Hero is
     * @param def how physically sturdy the Hero is
     */
    public Hero(int maxHP, int currentHP, int str, int def)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
    }
    
    /**
     * Even more advanced constructor that adds magic and magic defense
     * @param maxHP the maximum amount of health the Hero can have
     * @param currentHP the current health of the Hero
     * @param str how physically strong the Hero is
     * @param def how physically sturdy the Hero is
     * @param magic how magically strong the Hero is
     * @param magicDef how magically sturdy the Hero is
     */
    public Hero(int maxHP, int currentHP, int str, int def, int magic, int magicDef)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
    }
    
    /**
     * Even more advanced constructor that adds speed
     * @param maxHP the maximum amount of health the Hero can have
     * @param currentHP the current health of the Hero
     * @param str how physically strong the Hero is
     * @param def how physically sturdy the Hero is
     * @param magic how magically strong the Hero is
     * @param magicDef how magically sturdy the Hero is
     * @param spd how fast the Hero is
     */
    public Hero(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
        setSpd(spd);
    }
    
    /**
     * Full Constructor that introduces resistances and a few booleans
     * @param maxHP the maximum amount of health the Hero can have
     * @param currentHP the current health of the Hero
     * @param str how physically strong the Hero is
     * @param def how physically sturdy the Hero is
     * @param magic how magically strong the Hero is
     * @param magicDef how magically sturdy the Hero is
     * @param spd how fast the Hero is
     * @param resistances what damage types the Hero is weak/resistant to
     * @param isMyTurn whether it is the Hero's turn or not
     * @param isDefending whether the Hero is defending or not
     * @param status the current status of the Hero
     * @param healingCharges the number of times the Hero can use their healingAbility
     * @param creatureType what type of Hero it is
     */
    public Hero(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd, Double[] resistances, boolean isMyTurn, boolean isDefending, String status, int healingCharges, String creatureType)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
        setSpd(spd);
        setResistances(resistances);
        setCreatureLevel();
        setIsMyTurn(isMyTurn);
        setIsDefending(isDefending);
        setStatus(status);
        setHealingCharges(healingCharges);
        setCreatureType(creatureType);
    }
    
    // METHODS
    
    public void healingAbility(Creature target){}
    
    public void levelUp(){}
}

package finalprojectfight;


import java.util.Random;
/**
 *
 * @author Alex McMullen
 */
public class Knight extends Hero
{
    // INITIALIZATIONS //
    
    // The number of times the Knight can use their healingAbility
    final private int KNIGHT_STARTING_HEALING_CHARGES = 7;
    final private int KNIGHT_HEALING_CHARGE_LEVEL_BONUS = 2;
    
    // Initializing the different hp values for the Knight
    final private int KNIGHT_MIN_BASE_HP = 100;
    final private int KNIGHT_MAX_BASE_HP = 200;
    final private int KNIGHT_BASE_HP_RANGE = KNIGHT_MAX_BASE_HP - KNIGHT_MIN_BASE_HP + 1;
    final private int KNIGHT_HP_LEVEL_BONUS = 50;
    
    // Initializing the different str values for the Knight
    final private int KNIGHT_MIN_BASE_STR = 40;
    final private int KNIGHT_MAX_BASE_STR = 70;
    final private int KNIGHT_BASE_STR_RANGE = KNIGHT_MAX_BASE_STR - KNIGHT_MIN_BASE_STR + 1;
    final private int KNIGHT_STR_LEVEL_BONUS = 5;
    
    // Initializing the different def values for the Knight
    final private int KNIGHT_MIN_BASE_DEF = 50;
    final private int KNIGHT_MAX_BASE_DEF = 90;
    final private int KNIGHT_BASE_DEF_RANGE = KNIGHT_MAX_BASE_DEF - KNIGHT_MIN_BASE_DEF + 1;
    final private int KNIGHT_DEF_LEVEL_BONUS = 10;
    
    // Initializing the different magic values for the Knight
    final private int KNIGHT_MIN_BASE_MAGIC = 10;
    final private int KNIGHT_MAX_BASE_MAGIC = 30;
    final private int KNIGHT_BASE_MAGIC_RANGE = KNIGHT_MAX_BASE_MAGIC - KNIGHT_MIN_BASE_MAGIC + 1;
    final private int KNIGHT_MAGIC_LEVEL_BONUS = 2;
    
    // Initializing the different magicDef values for the Knight
    final private int KNIGHT_MIN_BASE_MAGIC_DEF = 30;
    final private int KNIGHT_MAX_BASE_MAGIC_DEF = 50;
    final private int KNIGHT_BASE_MAGIC_DEF_RANGE = KNIGHT_MAX_BASE_MAGIC_DEF - KNIGHT_MIN_BASE_MAGIC_DEF + 1;
    final private int KNIGHT_MAGIC_DEF_LEVEL_BONUS = 4;
    
    // Initializing the different spd values for the Knight
    final private int KNIGHT_MIN_BASE_SPD = 25;
    final private int KNIGHT_MAX_BASE_SPD = 50;
    final private int KNIGHT_BASE_SPD_RANGE = KNIGHT_MAX_BASE_SPD - KNIGHT_MIN_BASE_SPD + 1;
    final private int KNIGHT_SPD_LEVEL_BONUS = 3;
    
    // A random number generator to make the stats for the Knight
    final private Random RANDOM_STAT_GENERATOR = new Random();
    
    final private int KNIGHT_STARTING_HP = KNIGHT_MIN_BASE_HP + RANDOM_STAT_GENERATOR.nextInt(KNIGHT_BASE_HP_RANGE);
    final private int KNIGHT_STARTING_STR = KNIGHT_MIN_BASE_STR + RANDOM_STAT_GENERATOR.nextInt(KNIGHT_BASE_STR_RANGE);
    final private int KNIGHT_STARTING_DEF = KNIGHT_MIN_BASE_DEF + RANDOM_STAT_GENERATOR.nextInt(KNIGHT_BASE_DEF_RANGE);
    final private int KNIGHT_STARTING_MAGIC = KNIGHT_MIN_BASE_MAGIC + RANDOM_STAT_GENERATOR.nextInt(KNIGHT_BASE_MAGIC_RANGE);
    final private int KNIGHT_STARTING_MAGIC_DEF = KNIGHT_MIN_BASE_MAGIC_DEF + RANDOM_STAT_GENERATOR.nextInt(KNIGHT_BASE_MAGIC_DEF_RANGE);
    final private int KNIGHT_STARTING_SPD = KNIGHT_MIN_BASE_SPD + RANDOM_STAT_GENERATOR.nextInt(KNIGHT_BASE_SPD_RANGE);
    
    // Constructors //
    
    /**
     * Empty Constructor
     */
    public Knight()
    {
        
    }
    
    /**
     * Simple Knight constructor that only has a max health and its current health
     * @param maxHP the maximum health the Knight can have
     * @param currentHP the current health of the Knight
     */
    public Knight(int maxHP, int currentHP)
    {
        setMaxHP(KNIGHT_STARTING_HP);
        setCurrentHP(KNIGHT_STARTING_HP);
    }
    
    /**
     * Slightly more advanced constructor that contains the Knight's max health, current health, strength, and defense
     * @param maxHP the maximum health the Knight can have
     * @param currentHP the current health of the Knight
     * @param str how physically strong the Knight is
     * @param def how physically sturdy the Knight is
     */
    public Knight(int maxHP, int currentHP, int str, int def)
    {
        setMaxHP(KNIGHT_STARTING_HP);
        setCurrentHP(KNIGHT_STARTING_HP);
        setStr(KNIGHT_STARTING_STR);
        setDef(KNIGHT_STARTING_DEF);
    }
    
    /**
     * Even more advanced constructor that adds magic and magic defense
     * @param maxHP the maximum amount of health the Knight can have
     * @param currentHP the current health of the Knight
     * @param str how physically strong the Knight is
     * @param def how physically sturdy the Knight is
     * @param magic how magically strong the Knight is
     * @param magicDef how magically sturdy the Knight is
     */
    public Knight(int maxHP, int currentHP, int str, int def, int magic, int magicDef)
    {
        setMaxHP(KNIGHT_STARTING_HP);
        setCurrentHP(KNIGHT_STARTING_HP);
        setStr(KNIGHT_STARTING_STR);
        setDef(KNIGHT_STARTING_DEF);
        setMagic(KNIGHT_STARTING_MAGIC);
        setMagicDef(KNIGHT_STARTING_MAGIC_DEF);
    }
    
    /**
     * Even more advanced constructor that adds speed
     * @param maxHP the maximum amount of health the Knight can have
     * @param currentHP the current health of the Knight
     * @param str how physically strong the Knight is
     * @param def how physically sturdy the Knight is
     * @param magic how magically strong the Knight is
     * @param magicDef how magically sturdy the Knight is
     * @param spd how fast the Knight is
     */
    public Knight(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd)
    {
        setMaxHP(KNIGHT_STARTING_HP);
        setCurrentHP(KNIGHT_STARTING_HP);
        setStr(KNIGHT_STARTING_STR);
        setDef(KNIGHT_STARTING_DEF);
        setMagic(KNIGHT_STARTING_MAGIC);
        setMagicDef(KNIGHT_STARTING_MAGIC_DEF);
        setSpd(KNIGHT_STARTING_SPD);
    }
    
    /**
     * Full Constructor that introduces resistances and a few booleans
     * @param maxHP the maximum amount of health the Knight can have
     * @param currentHP the current health of the Knight
     * @param str how physically strong the Knight is
     * @param def how physically sturdy the Knight is
     * @param magic how magically strong the Knight is
     * @param magicDef how magically sturdy the Knight is
     * @param spd how fast the Knight is
     * @param resistances what damage types the Knight is weak/resistant to
     * @param isMyTurn whether it is the Knight's turn or not
     * @param isDefending whether the Knight is defending or not
     * @param status the current status of the Knight
     * @param healingCharges the number of times the Knight can use their healingAbility
     * @param creatureType what kind of Creature it is
     */
    public Knight(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd, Double[] resistances, boolean isMyTurn, boolean isDefending, String status, int healingCharges, String creatureType)
    {
        this.setResistanceLevels(1.5, 1.0, 2.0, 1.0, 0.75, 0.75, 1.0, 0.5);
        setMaxHP(KNIGHT_STARTING_HP);
        setCurrentHP(KNIGHT_STARTING_HP);
        setStr(KNIGHT_STARTING_STR);
        setDef(KNIGHT_STARTING_DEF);
        setMagic(KNIGHT_STARTING_MAGIC);
        setMagicDef(KNIGHT_STARTING_MAGIC_DEF);
        setSpd(KNIGHT_STARTING_SPD);
        setResistances(resistances);
        setCreatureLevel();
        setIsMyTurn(isMyTurn);
        setIsDefending(isDefending);
        setStatus("Healthy");
        setHealingCharges(KNIGHT_STARTING_HEALING_CHARGES);
        setCreatureType("Knight");
    }
    
    // Methods //
    
    /**
     * The Knight's basic attack
     * @param target the Creature the Knight is attacking
     */
    @Override
    public void attack(Creature target)
    {
        super.attack(target);
        
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        String damageType = "Physical";
        String damageSubType = "Slashing";
        int power = 50;
        
        int pureDamage = power * this.getStr();
        int adjustedDamage = pureDamage / target.getDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getSlashResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        target.checkStatus(this);
    }
    
    /**
     * The first of 3 Offensive Abilities for the Knight
     * The Knight foregoes any sword training they have received and instead repeatedly punch the enemy
     * @param target the Creature the Knight is attacking
     */
    @Override
    public void offensiveAbility1(Creature target)
    {
       super.offensiveAbility1(target);
       if(!this.getIsMyTurn())
        {
            return;
        }
       
       String damageType = "Physical";
       String damageSubType = "Blunt";
       int power = 20;
       
       Random hitRandom = new Random();
       int maxHits = 5;
       int generatedHits = hitRandom.nextInt(maxHits) + 1;
       
       int effectivePower = generatedHits * power;
       int pureDamage = effectivePower * this.getStr();
       int adjustedDamage = (int)(pureDamage / target.getDef());
       
       int damageAfterResistance = (int)(adjustedDamage / target.getBluntResistance());
       
       if(target.getIsDefending())
       {
           damageAfterResistance /= 2;
           target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
       }
       else
       {
           target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
       }
       
       target.checkStatus(this);
    }
    
    /**
     * The second of 3 Offensive Abilities for the Knight
     * The Knight takes their blade and thrusts it straight through the enemy
     * @param target the Creature the Knight is attacking
     */
    @Override
    public void offensiveAbility2(Creature target)
    {
        super.offensiveAbility2(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        String damageType = "Physical";
        String damageSubType = "Thrust";
        int power = 80;
        
        int pureDamage = power * this.getStr();
        int adjustedDamage = pureDamage / target.getDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getThrustResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        target.checkStatus(this);
    }
    
    /**
     * The third of 3 Offensive Abilities for the Knight
     * The Knight attempts to pull off an amazing maneuver with... varying results
     * @param target the Creature the Knight is attacking
     */
    @Override
    public void offensiveAbility3(Creature target)
    {
        super.offensiveAbility3(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        String damageType = "Physical";
        String damageSubType = "Physical";
        
        Random powerGenerator = new Random();
        int power = powerGenerator.nextInt(71) + 50;
        int pureDamage = power * this.getStr();
        int adjustedDamage = pureDamage / target.getDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getPhysicalResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        target.checkStatus(this);
    }
    
    /**
     * The Knight's Healing Ability
     * The Knight uses their knowledge of battlefield first aid to mitigate some of the damage they've sustained
     */
    @Override
    public void healingAbility(Creature target)
    {
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        Random percentGenerator = new Random();
        int healingPercent = percentGenerator.nextInt(21) + 40;
        int healthHealed = (int)((healingPercent * this.getMaxHP())/100);
        if(this.getCurrentHP() + healthHealed > this.getMaxHP())
        {
            this.setCurrentHP(this.getMaxHP());
        }
        else
        {
            this.setCurrentHP(this.getCurrentHP() + healthHealed);
        }
        
        target.checkStatus(this);
    }
    
    /**
     * The stat increases the Knight gets when they make it to the next level of the dungeon
     */
    @Override
    public void levelUp()
    {
        this.setMaxHP(maxHP + KNIGHT_HP_LEVEL_BONUS);
        this.setCurrentHP(maxHP + KNIGHT_HP_LEVEL_BONUS);
        this.setStr(str + KNIGHT_STR_LEVEL_BONUS);
        this.setDef(def + KNIGHT_DEF_LEVEL_BONUS);
        this.setMagic(magic + KNIGHT_MAGIC_LEVEL_BONUS);
        this.setMagicDef(magicDef + KNIGHT_MAGIC_DEF_LEVEL_BONUS);
        this.setSpd(spd + KNIGHT_SPD_LEVEL_BONUS);
        this.setHealingCharges(KNIGHT_STARTING_HEALING_CHARGES + (KNIGHT_HEALING_CHARGE_LEVEL_BONUS * dungeonLevel));
    }
    
    
}

package finalprojectfight;

import java.util.Random;

/**
 *
 * @author Alex McMullen
 */
public class LizardMan extends Enemy
{
    // INITIALIZATIONS //
    
    // Initializing the different hp values for the LizardMan
    final private int LIZARD_MAN_MIN_BASE_HP = 75;
    final private int LIZARD_MAN_MAX_BASE_HP = 125;
    final private int LIZARD_MAN_BASE_HP_RANGE = LIZARD_MAN_MAX_BASE_HP - LIZARD_MAN_MIN_BASE_HP + 1;
    final private int LIZARD_MAN_HP_LEVEL_BONUS = 50;
    
    // Initializing the different str values for the LizardMan
    final private int LIZARD_MAN_MIN_BASE_STR = 20;
    final private int LIZARD_MAN_MAX_BASE_STR = 50;
    final private int LIZARD_MAN_BASE_STR_RANGE = LIZARD_MAN_MAX_BASE_STR - LIZARD_MAN_MIN_BASE_STR + 1;
    final private int LIZARD_MAN_STR_LEVEL_BONUS = 5;
    
    // Initializing the different def values for the LizardMan
    final private int LIZARD_MAN_MIN_BASE_DEF = 30;
    final private int LIZARD_MAN_MAX_BASE_DEF = 60;
    final private int LIZARD_MAN_BASE_DEF_RANGE = LIZARD_MAN_MAX_BASE_DEF - LIZARD_MAN_MIN_BASE_DEF + 1;
    final private int LIZARD_MAN_DEF_LEVEL_BONUS = 10;
    
    // Initializing the different magic values for the LizardMan
    final private int LIZARD_MAN_MIN_BASE_MAGIC = 10;
    final private int LIZARD_MAN_MAX_BASE_MAGIC = 30;
    final private int LIZARD_MAN_BASE_MAGIC_RANGE = LIZARD_MAN_MAX_BASE_MAGIC - LIZARD_MAN_MIN_BASE_MAGIC + 1;
    final private int LIZARD_MAN_MAGIC_LEVEL_BONUS = 5;
    
    // Initializing the different magicDef values for the LizardMan
    final private int LIZARD_MAN_MIN_BASE_MAGIC_DEF = 30;
    final private int LIZARD_MAN_MAX_BASE_MAGIC_DEF = 50;
    final private int LIZARD_MAN_BASE_MAGIC_DEF_RANGE = LIZARD_MAN_MAX_BASE_MAGIC_DEF - LIZARD_MAN_MIN_BASE_MAGIC_DEF + 1;
    final private int LIZARD_MAN_MAGIC_DEF_LEVEL_BONUS = 10;
    
    // Initializing the different spd values for the LizardMan
    final private int LIZARD_MAN_MIN_BASE_SPD = 30;
    final private int LIZARD_MAN_MAX_BASE_SPD = 60;
    final private int LIZARD_MAN_BASE_SPD_RANGE = LIZARD_MAN_MAX_BASE_SPD - LIZARD_MAN_MIN_BASE_SPD + 1;
    final private int LIZARD_MAN_SPD_LEVEL_BONUS = 5;
    
    // A random number generator to make the stats for the LizardMan
    final private Random RANDOM_STAT_GENERATOR = new Random();
    
    final private int LIZARD_MAN_STARTING_HP = LIZARD_MAN_MIN_BASE_HP + RANDOM_STAT_GENERATOR.nextInt(LIZARD_MAN_BASE_HP_RANGE);
    final private int LIZARD_MAN_STARTING_STR = LIZARD_MAN_MIN_BASE_STR + RANDOM_STAT_GENERATOR.nextInt(LIZARD_MAN_BASE_STR_RANGE);
    final private int LIZARD_MAN_STARTING_DEF = LIZARD_MAN_MIN_BASE_DEF + RANDOM_STAT_GENERATOR.nextInt(LIZARD_MAN_BASE_DEF_RANGE);
    final private int LIZARD_MAN_STARTING_MAGIC = LIZARD_MAN_MIN_BASE_MAGIC + RANDOM_STAT_GENERATOR.nextInt(LIZARD_MAN_BASE_MAGIC_RANGE);
    final private int LIZARD_MAN_STARTING_MAGIC_DEF = LIZARD_MAN_MIN_BASE_MAGIC_DEF + RANDOM_STAT_GENERATOR.nextInt(LIZARD_MAN_BASE_MAGIC_DEF_RANGE);
    final private int LIZARD_MAN_STARTING_SPD = LIZARD_MAN_MIN_BASE_SPD + RANDOM_STAT_GENERATOR.nextInt(LIZARD_MAN_BASE_SPD_RANGE);
    
    // Constructors //
    
    /**
     * Empty Constructor
     */
    public LizardMan()
    {
        
    }
    
    /**
     * Simple LizardMan constructor that only has a max health and its current health
     * @param maxHP the maximum health the LizardMan can have
     * @param currentHP the current health of the LizardMan
     */
    public LizardMan(int maxHP, int currentHP)
    {
        setMaxHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
    }
    
    /**
     * Slightly more advanced constructor that contains the LizardMan's max health, current health, strength, and defense
     * @param maxHP the maximum health the LizardMan can have
     * @param currentHP the current health of the LizardMan
     * @param str how physically strong the LizardMan is
     * @param def how physically sturdy the LizardMan is
     */
    public LizardMan(int maxHP, int currentHP, int str, int def)
    {
        setMaxHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setStr(LIZARD_MAN_STARTING_STR + (LIZARD_MAN_STR_LEVEL_BONUS * dungeonLevel));
        setDef(LIZARD_MAN_STARTING_DEF + (LIZARD_MAN_DEF_LEVEL_BONUS * dungeonLevel));
    }
    
    /**
     * Even more advanced constructor that adds magic and magic defense
     * @param maxHP the maximum amount of health the LizardMan can have
     * @param currentHP the current health of the LizardMan
     * @param str how physically strong the LizardMan is
     * @param def how physically sturdy the LizardMan is
     * @param magic how magically strong the LizardMan is
     * @param magicDef how magically sturdy the LizardMan is
     */
    public LizardMan(int maxHP, int currentHP, int str, int def, int magic, int magicDef)
    {
        setMaxHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setStr(LIZARD_MAN_STARTING_STR + (LIZARD_MAN_STR_LEVEL_BONUS * dungeonLevel));
        setDef(LIZARD_MAN_STARTING_DEF + (LIZARD_MAN_DEF_LEVEL_BONUS * dungeonLevel));
        setMagic(LIZARD_MAN_STARTING_MAGIC + (LIZARD_MAN_MAGIC_LEVEL_BONUS * dungeonLevel));
        setMagicDef(LIZARD_MAN_STARTING_MAGIC_DEF + (LIZARD_MAN_MAGIC_DEF_LEVEL_BONUS * dungeonLevel));
    }
    
    /**
     * Even more advanced constructor that adds speed
     * @param maxHP the maximum amount of health the LizardMan can have
     * @param currentHP the current health of the LizardMan
     * @param str how physically strong the LizardMan is
     * @param def how physically sturdy the LizardMan is
     * @param magic how magically strong the LizardMan is
     * @param magicDef how magically sturdy the LizardMan is
     * @param spd how fast the LizardMan is
     */
    public LizardMan(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd)
    {
        setMaxHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setStr(LIZARD_MAN_STARTING_STR + (LIZARD_MAN_STR_LEVEL_BONUS * dungeonLevel));
        setDef(LIZARD_MAN_STARTING_DEF + (LIZARD_MAN_DEF_LEVEL_BONUS * dungeonLevel));
        setMagic(LIZARD_MAN_STARTING_MAGIC + (LIZARD_MAN_MAGIC_LEVEL_BONUS * dungeonLevel));
        setMagicDef(LIZARD_MAN_STARTING_MAGIC_DEF + (LIZARD_MAN_MAGIC_DEF_LEVEL_BONUS * dungeonLevel));
        setSpd(LIZARD_MAN_STARTING_SPD + (LIZARD_MAN_SPD_LEVEL_BONUS * dungeonLevel));
    }
    
    /**
     * Full Constructor that introduces resistances and a few booleans
     * @param maxHP the maximum amount of health the LizardMan can have
     * @param currentHP the current health of the LizardMan
     * @param str how physically strong the LizardMan is
     * @param def how physically sturdy the LizardMan is
     * @param magic how magically strong the LizardMan is
     * @param magicDef how magically sturdy the LizardMan is
     * @param spd how fast the LizardMan is
     * @param resistances what damage types the LizardMan is weak/resistant to
     * @param isMyTurn whether it is the LizardMan's turn or not
     * @param isDefending whether the LizardMan is defending or not
     * @param status the current status of the LizardMan
     * @param healingCharges the number of times the LizardMan can heal
     * @param what type of Creature it is
     */
    public LizardMan(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd, Double[] resistances, boolean isMyTurn, boolean isDefending, String status, int healingCharges, String creatureType)
    {
        this.setResistanceLevels(1.0, 1.0, 1.25, 0.75, 1.0, 1.0, 0.75, 1.0);
        setMaxHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(LIZARD_MAN_STARTING_HP + (LIZARD_MAN_HP_LEVEL_BONUS * dungeonLevel));
        setStr(LIZARD_MAN_STARTING_STR + (LIZARD_MAN_STR_LEVEL_BONUS * dungeonLevel));
        setDef(LIZARD_MAN_STARTING_DEF + (LIZARD_MAN_DEF_LEVEL_BONUS * dungeonLevel));
        setMagic(LIZARD_MAN_STARTING_MAGIC + (LIZARD_MAN_MAGIC_LEVEL_BONUS * dungeonLevel));
        setMagicDef(LIZARD_MAN_STARTING_MAGIC_DEF + (LIZARD_MAN_MAGIC_DEF_LEVEL_BONUS * dungeonLevel));
        setSpd(LIZARD_MAN_STARTING_SPD + (LIZARD_MAN_SPD_LEVEL_BONUS * dungeonLevel));
        setResistances(resistances);
        setCreatureLevel();
        setIsMyTurn(isMyTurn);
        setIsDefending(isDefending);
        setStatus("Healthy");
        setHealingCharges(0);
        setCreatureType("LizardMan");
    }
    
    // Methods //
    
    /**
     * The LizardMan's basic attack
     * @param target the Creature the LizardMan is attacking
     */
    @Override
    public void attack(Creature target)
    {
        super.attack(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        String damageType = "Physical";
        String damageSubType = "Slashing";
        int power = 50;
        
        int pureDamage = power * this.getStr();
        int adjustedDamage = pureDamage / target.getDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getSlashResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        this.enemyCheck((Hero)target);
        target.checkStatus(this);
    }
    
    /**
     * The LizardMan's first of 3 offensive abilities
     * The LizardMan uses its tail to smack the Creature 2x
     * @param target the Creature the LizardMan is attacking
     */
    @Override
    public void offensiveAbility1(Creature target)
    {
        super.offensiveAbility1(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        String damageType = "Physical";
        String damageSubType = "Blunt";
        int power = 80;
        
        int pureDamage = power * this.getStr();
        int adjustedDamage = pureDamage / target.getDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getBluntResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        this.enemyCheck((Hero)target);
        target.checkStatus(this);
    }
    
    /**
     * The 2nd of the LizardMan's 3 offensive abilities
     * The LizardMan spits from its innate poison sack, attempting to poison the target Creature
     * @param target the Creature the LizardMan is attacking
     */
    @Override
    public void offensiveAbility2(Creature target)
    {
        super.offensiveAbility2(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        Random poisonChecker = new Random();
        
        String damageType = "Magic";
        String damageSubType = "Magic";
        int power = 30;
        double poisonChance = 0.2;
        
        int pureDamage = power * this.getMagic();
        int adjustedDamage = pureDamage / target.getMagicDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getMagicResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        if(poisonChecker.nextDouble() <= poisonChance && target.getStatus().equals("Healthy"))
        {
            target.setStatus("Poisoned");
        }
        
        this.enemyCheck((Hero)target);
        target.checkStatus(this);
    }
    
    /**
     * The 3rd of the 3 offensive abilities of the LizardMan
     * The LizardMan lunges and attempts to bite down on the target Creature with their powerful jaws
     * @param target the Creature the LizardMan is attacking
     */
    @Override
    public void offensiveAbility3(Creature target)
    {
        super.offensiveAbility3(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        Random hitChecker = new Random();
        
        String damageType = "Physical";
        String damageSubType = "Thrust";
        int power = 120;
        double accuracy = 0.9;
        
        int pureDamage = power * this.getStr();
        int adjustedDamage = pureDamage / target.getDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getThrustResistance());
        
        if(hitChecker.nextDouble() <= accuracy)
        {
            if(target.getIsDefending())
            {
                damageAfterResistance /= 2;
                target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
            }
            else
            {
                target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
            }
        }
        
        this.enemyCheck((Hero)target);
        target.checkStatus(this);
    }
    
    
}

package finalprojectfight;

import java.util.Random;

/**
 *
 * @author Alex McMullen
 */
public class Enemy extends Creature
{
    // CONSTRUCTORS
    
    /**
     * Empty Constructor
     */
    public Enemy()
    {
        
    }
    
    /**
     * Simple Enemy constructor that only has a max health and its current health
     * @param maxHP the maximum health the Enemy can have
     * @param currentHP the current health of the Enemy
     */
    public Enemy(int maxHP, int currentHP)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
    }
    
    /**
     * Slightly more advanced constructor that contains the Enemy's max health, current health, strength, and defense
     * @param maxHP the maximum health the Enemy can have
     * @param currentHP the current health of the Enemy
     * @param str how physically strong the Enemy is
     * @param def how physically sturdy the Enemy is
     */
    public Enemy(int maxHP, int currentHP, int str, int def)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
    }
    
    /**
     * Even more advanced constructor that adds magic and magic defense
     * @param maxHP the maximum amount of health the Enemy can have
     * @param currentHP the current health of the Enemy
     * @param str how physically strong the Enemy is
     * @param def how physically sturdy the Enemy is
     * @param magic how magically strong the Enemy is
     * @param magicDef how magically sturdy the Enemy is
     */
    public Enemy(int maxHP, int currentHP, int str, int def, int magic, int magicDef)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
    }
    
    /**
     * Even more advanced constructor that adds speed
     * @param maxHP the maximum amount of health the Enemy can have
     * @param currentHP the current health of the Enemy
     * @param str how physically strong the Enemy is
     * @param def how physically sturdy the Enemy is
     * @param magic how magically strong the Enemy is
     * @param magicDef how magically sturdy the Enemy is
     * @param spd how fast the Enemy is
     */
    public Enemy(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
        setSpd(spd);
    }
    
    /**
     * Full Constructor that introduces resistances
     * @param maxHP the maximum amount of health the Enemy can have
     * @param currentHP the current health of the Enemy
     * @param str how physically strong the Enemy is
     * @param def how physically sturdy the Enemy is
     * @param magic how magically strong the Enemy is
     * @param magicDef how magically sturdy the Enemy is
     * @param spd how fast the Enemy is
     * @param resistances what damage types the Enemy is weak/resistant to
     * @param isMyTurn whether it is the Enemy's turn or not
     * @param isDefending whether the Enemy is defending or not
     * @param status the current status of the Enemy
     * @param healingCharges the number of times the Enemy can heal. Enemies can not heal and is automatically set to 0
     * @param what type of Enemy it is
     */
    public Enemy(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd, Double[] resistances, boolean isMyTurn, boolean isDefending, String status, int healingCharges, String creatureType)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
        setSpd(spd);
        setResistances(resistances);
        setCreatureLevel();
        setIsMyTurn(isMyTurn);
        setIsDefending(isDefending);
        setStatus(status);
        setHealingCharges(0);
        setCreatureType(creatureType);
    }
    
    // Methods //
    
    public void takeTurn(Creature target)
    {
        Random choices = new Random();
        int move = choices.nextInt(5) + 1;
        System.out.println(move);
        switch(move)
        {
            case 1: this.attack(target);
                    break;
            case 2: this.defend(target);
                    break;
            case 3: this.offensiveAbility1(target);
                    break;
            case 4: this.offensiveAbility2(target);
                    break;
            case 5: this.offensiveAbility3(target);
                    break;
            default: break;
        }
    }
    
    /**
     * Method that causes the Hero to level up when the Enemy dies
     * @param attacker the Hero that is attacking the Enemy
     */
    public void enemyCheck(Hero attacker)
    {
        if(this.getStatus().equals("Dead"))
        {
            attacker.levelUp();
            attacker.levelUp();
            attacker.levelUp();
            attacker.levelUp();
            attacker.levelUp();
        }
    }
}

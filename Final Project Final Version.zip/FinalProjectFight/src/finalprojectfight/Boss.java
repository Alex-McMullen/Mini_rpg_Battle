package finalprojectfight;

import java.util.Random;

/**
 *
 * @author Alex McMullen
 */
public class Boss extends Enemy
{
    // INITIALIZATIONS //
    
    // Initializing the different hp values for the Boss
    final private int BOSS_MIN_BASE_HP = 125;
    final private int BOSS_MAX_BASE_HP = 200;
    final private int BOSS_BASE_HP_RANGE = BOSS_MAX_BASE_HP - BOSS_MIN_BASE_HP + 1;
    final private int BOSS_HP_LEVEL_BONUS = 50;
    
    // Initializing the different str values for the Boss
    final private int BOSS_MIN_BASE_STR = 30;
    final private int BOSS_MAX_BASE_STR = 60;
    final private int BOSS_BASE_STR_RANGE = BOSS_MAX_BASE_STR - BOSS_MIN_BASE_STR + 1;
    final private int BOSS_STR_LEVEL_BONUS = 7;
    
    // Initializing the different def values for the Boss
    final private int BOSS_MIN_BASE_DEF = 30;
    final private int BOSS_MAX_BASE_DEF = 60;
    final private int BOSS_BASE_DEF_RANGE = BOSS_MAX_BASE_DEF - BOSS_MIN_BASE_DEF + 1;
    final private int BOSS_DEF_LEVEL_BONUS = 7;
    
    // Initializing the different magic values for the Boss
    final private int BOSS_MIN_BASE_MAGIC = 30;
    final private int BOSS_MAX_BASE_MAGIC = 60;
    final private int BOSS_BASE_MAGIC_RANGE = BOSS_MAX_BASE_MAGIC - BOSS_MIN_BASE_MAGIC + 1;
    final private int BOSS_MAGIC_LEVEL_BONUS = 7;
    
    // Initializing the different magicDef values for the Boss
    final private int BOSS_MIN_BASE_MAGIC_DEF = 30;
    final private int BOSS_MAX_BASE_MAGIC_DEF = 60;
    final private int BOSS_BASE_MAGIC_DEF_RANGE = BOSS_MAX_BASE_MAGIC_DEF - BOSS_MIN_BASE_MAGIC_DEF + 1;
    final private int BOSS_MAGIC_DEF_LEVEL_BONUS = 7;
    
    // Initializing the different spd values for the Boss
    final private int BOSS_MIN_BASE_SPD = 30;
    final private int BOSS_MAX_BASE_SPD = 60;
    final private int BOSS_BASE_SPD_RANGE = BOSS_MAX_BASE_SPD - BOSS_MIN_BASE_SPD + 1;
    final private int BOSS_SPD_LEVEL_BONUS = 7;
    
    // A random number generator to make the stats for the Boss
    final private Random RANDOM_STAT_GENERATOR = new Random();
    
    final private int BOSS_STARTING_HP = BOSS_MIN_BASE_HP + RANDOM_STAT_GENERATOR.nextInt(BOSS_BASE_HP_RANGE);
    final private int BOSS_STARTING_STR = BOSS_MIN_BASE_STR + RANDOM_STAT_GENERATOR.nextInt(BOSS_BASE_STR_RANGE);
    final private int BOSS_STARTING_DEF = BOSS_MIN_BASE_DEF + RANDOM_STAT_GENERATOR.nextInt(BOSS_BASE_DEF_RANGE);
    final private int BOSS_STARTING_MAGIC = BOSS_MIN_BASE_MAGIC + RANDOM_STAT_GENERATOR.nextInt(BOSS_BASE_MAGIC_RANGE);
    final private int BOSS_STARTING_MAGIC_DEF = BOSS_MIN_BASE_MAGIC_DEF + RANDOM_STAT_GENERATOR.nextInt(BOSS_BASE_MAGIC_DEF_RANGE);
    final private int BOSS_STARTING_SPD = BOSS_MIN_BASE_SPD + RANDOM_STAT_GENERATOR.nextInt(BOSS_BASE_SPD_RANGE);
    
    // Constructors //
    
    /**
     * Empty Constructor
     */
    public Boss()
    {
        
    }
    
    /**
     * Simple Boss constructor that only has a max health and its current health
     * @param maxHP the maximum health the Boss can have
     * @param currentHP the current health of the Boss
     */
    public Boss(int maxHP, int currentHP)
    {
        setMaxHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
    }
    
    /**
     * Slightly more advanced constructor that contains the Boss's max health, current health, strength, and defense
     * @param maxHP the maximum health the Boss can have
     * @param currentHP the current health of the Boss
     * @param str how physically strong the Boss is
     * @param def how physically sturdy the Boss is
     */
    public Boss(int maxHP, int currentHP, int str, int def)
    {
        setMaxHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setStr(BOSS_STARTING_STR + (BOSS_STR_LEVEL_BONUS * dungeonLevel));
        setDef(BOSS_STARTING_DEF + (BOSS_DEF_LEVEL_BONUS * dungeonLevel));
    }
    
    /**
     * Even more advanced constructor that adds magic and magic defense
     * @param maxHP the maximum amount of health the Boss can have
     * @param currentHP the current health of the Boss
     * @param str how physically strong the Boss is
     * @param def how physically sturdy the Boss is
     * @param magic how magically strong the Boss is
     * @param magicDef how magically sturdy the Boss is
     */
    public Boss(int maxHP, int currentHP, int str, int def, int magic, int magicDef)
    {
        setMaxHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setStr(BOSS_STARTING_STR + (BOSS_STR_LEVEL_BONUS * dungeonLevel));
        setDef(BOSS_STARTING_DEF + (BOSS_DEF_LEVEL_BONUS * dungeonLevel));
        setMagic(BOSS_STARTING_MAGIC + (BOSS_MAGIC_LEVEL_BONUS * dungeonLevel));
        setMagicDef(BOSS_STARTING_MAGIC_DEF + (BOSS_MAGIC_DEF_LEVEL_BONUS * dungeonLevel));
    }
    
    /**
     * Even more advanced constructor that adds speed
     * @param maxHP the maximum amount of health the Boss can have
     * @param currentHP the current health of the Boss
     * @param str how physically strong the Boss is
     * @param def how physically sturdy the Boss is
     * @param magic how magically strong the Boss is
     * @param magicDef how magically sturdy the Boss is
     * @param spd how fast the Boss is
     */
    public Boss(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd)
    {
        setMaxHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setStr(BOSS_STARTING_STR + (BOSS_STR_LEVEL_BONUS * dungeonLevel));
        setDef(BOSS_STARTING_DEF + (BOSS_DEF_LEVEL_BONUS * dungeonLevel));
        setMagic(BOSS_STARTING_MAGIC + (BOSS_MAGIC_LEVEL_BONUS * dungeonLevel));
        setMagicDef(BOSS_STARTING_MAGIC_DEF + (BOSS_MAGIC_DEF_LEVEL_BONUS * dungeonLevel));
        setSpd(BOSS_STARTING_SPD + (BOSS_SPD_LEVEL_BONUS * dungeonLevel));
    }
    
    /**
     * Full Constructor that introduces resistances and a few booleans
     * @param maxHP the maximum amount of health the Boss can have
     * @param currentHP the current health of the Boss
     * @param str how physically strong the Boss is
     * @param def how physically sturdy the Boss is
     * @param magic how magically strong the Boss is
     * @param magicDef how magically sturdy the Boss is
     * @param spd how fast the Boss is
     * @param resistances what damage types the Boss is weak/resistant to
     * @param isMyTurn whether it is the Boss's turn or not
     * @param isDefending whether the Boss is defending or not
     * @param status the current status of the Boss
     * @param healingCharges the number of times the Boss can heal
     * @param what type of Creature it is
     */
    public Boss(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd, Double[] resistances, boolean isMyTurn, boolean isDefending, String status, int healingCharges, String creatureType)
    {
        this.setResistanceLevels(1.0, 1.0, 1.25, 0.75, 1.0, 1.0, 0.75, 1.0);
        setMaxHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setCurrentHP(BOSS_STARTING_HP + (BOSS_HP_LEVEL_BONUS * dungeonLevel));
        setStr(BOSS_STARTING_STR + (BOSS_STR_LEVEL_BONUS * dungeonLevel));
        setDef(BOSS_STARTING_DEF + (BOSS_DEF_LEVEL_BONUS * dungeonLevel));
        setMagic(BOSS_STARTING_MAGIC + (BOSS_MAGIC_LEVEL_BONUS * dungeonLevel));
        setMagicDef(BOSS_STARTING_MAGIC_DEF + (BOSS_MAGIC_DEF_LEVEL_BONUS * dungeonLevel));
        setSpd(BOSS_STARTING_SPD + (BOSS_SPD_LEVEL_BONUS * dungeonLevel));
        setResistances(resistances);
        setCreatureLevel();
        setIsMyTurn(isMyTurn);
        setIsDefending(isDefending);
        setStatus("Healthy");
        setHealingCharges(0);
        setCreatureType("Boss");
    }
    
    // Methods //
    
    /**
     * The Boss's basic attack
     * @param target the Creature the Boss is attacking
     */
    @Override
    public void attack(Creature target)
    {
        super.attack(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        String damageType = "Physical";
        String damageSubType = "Blunt";
        int power = 60;
        
        int pureDamage = power * this.getStr();
        int adjustedDamage = pureDamage / target.getDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getBluntResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        target.checkStatus(this);
        this.bossCheck((Hero)target);
    }
    
    /**
     * The Boss's first of 3 offensive abilities
     * The Boss breathes fire all over the Creature
     * @param target the Creature the Boss is attacking
     */
    @Override
    public void offensiveAbility1(Creature target)
    {
        super.offensiveAbility1(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        String damageType = "Magic";
        String damageSubType = "Fire";
        int power = 80;
        double burnChance = 0.2;
        
        Random burnCheck = new Random();
        
        int pureDamage = power * this.getMagic();
        int adjustedDamage = pureDamage / target.getMagicDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getFireResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        if(burnCheck.nextDouble() < burnChance)
        {
            if(target.getStatus().equals("Healthy"))
            {
                target.setStatus("Burned");
            }
        }
        
        target.checkStatus(this);
        this.bossCheck((Hero)target);
    }
    
    /**
     * The 2nd of the Boss's 3 offensive abilities
     * The Boss throws a ball of Ice at the Creature
     * @param target the Creature the Boss is attacking
     */
    @Override
    public void offensiveAbility2(Creature target)
    {
        super.offensiveAbility2(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        Random poisonChecker = new Random();
        
        String damageType = "Magic";
        String damageSubType = "Ice";
        int power = 70;
        double freezeChance = 0.2;
        
        int pureDamage = power * this.getMagic();
        int adjustedDamage = pureDamage / target.getMagicDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getIceResistance());
        
        if(target.getIsDefending())
        {
            damageAfterResistance /= 2;
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        else
        {
            target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
        }
        
        if(poisonChecker.nextDouble() <= freezeChance && target.getStatus().equals("Healthy"))
        {
            target.setStatus("Frozen");
        }
        
        target.checkStatus(this);
        this.bossCheck((Hero)target);
    }
    
    /**
     * The 3rd of the 3 offensive abilities of the Boss
     * The Boss lunges and attempts to bite down on the target Creature with their powerful jaws
     * @param target the Creature the Boss is attacking
     */
    @Override
    public void offensiveAbility3(Creature target)
    {
        super.offensiveAbility3(target);
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        Random hitChecker = new Random();
        
        String damageType = "Physical";
        String damageSubType = "Thrust";
        int power = 120;
        double accuracy = 0.9;
        
        int pureDamage = power * this.getStr();
        int adjustedDamage = pureDamage / target.getDef();
        int damageAfterResistance = (int)(adjustedDamage / target.getThrustResistance());
        
        if(hitChecker.nextDouble() <= accuracy)
        {
            if(target.getIsDefending())
            {
                damageAfterResistance /= 2;
                target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
            }
            else
            {
                target.setCurrentHP(target.getCurrentHP() - damageAfterResistance);
            }
        }
        
        target.checkStatus(this);
        this.bossCheck((Hero)target);
    }
    
    /**
     * Method that causes the Hero to level up when the Boss dies
     * @param attacker the Hero that is attacking the Boss
     */
    public void bossCheck(Hero attacker)
    {
        if(this.getStatus().equals("Dead"))
        {
            attacker.levelUp();
            attacker.levelUp();
            attacker.levelUp();
            attacker.levelUp();
            attacker.levelUp();
        }
    }
    
    
}

package finalprojectfight;

import java.util.Random;
/**
 *
 * @author Alex McMullen
 */
public class Creature 
{
    // INITIALIZATION
    
    // The level of the dungeon
    protected int dungeonLevel = 0;
    
    
    //  Max Health Points. The maximum amount of health a Creature may have
    protected int maxHP;
    public int getMaxHP()
    {
        return maxHP;
    }
    public void setMaxHP(int maxHP)
    {
        this.maxHP = maxHP;
    }
    
    // Current Health Points. The current amount of health a Creature has
    protected int currentHP;
    public int getCurrentHP()
    {
        return currentHP;
    }
    public void setCurrentHP(int currentHP)
    {
        this.currentHP = currentHP;
    }
    
    // Strength. Determines how much damage a Creature deals with physical attacks
    protected int str;
    public int getStr()
    {
        return str;
    }
    public void setStr(int str)
    {
        this.str = str;
    }
    
    // Defense. Determines how much damage a Creature takes from physical attacks
    protected int def;
    public int getDef()
    {
        return def;
    }
    public void setDef(int def)
    {
        this.def = def;
    }
    
    // Magic. Determines how much damaage a Creature deals with magical attacks
    protected int magic;
    public int getMagic()
    {
        return magic;
    }
    public void setMagic(int magic)
    {
        this.magic = magic;
    }
    
    // Magic Defense. Determines how much damage a Creature takes from magical attacks
    protected int magicDef;
    public int getMagicDef()
    {
        return magicDef;
    }
    public void setMagicDef(int magicDef)
    {
        this.magicDef = magicDef;
    }
    
    // Speed. The Creature with the highest speed goes first in a battle.
    protected int spd;
    public int getSpd()
    {
        return spd;
    }
    public void setSpd(int spd)
    {
        this.spd = spd;
    }
    
    // Status. The current status of the Creature.
    // Status can be: Healthy, Dead, Poisoned, Burned, Frozen, or Paralyzed
    protected String status = "";
    public String getStatus()
    {
        return status;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }
    
    /* A modifier to how much damage a Creature takes from regular physical attacks.
    The further from 0 the number is, the more beneficial the modifier.
    A number lower than 0 heals. */
    protected double physicalResistance = 1;
    public double getPhysicalResistance()
    {
        return physicalResistance;
    }
    public void setPhysicalResistance(double physicalResistance)
    {
        this.physicalResistance = physicalResistance;
    }
    
    /* A modifier to how much damage a Creature takes from blunt attacks.
    Blunt attacks are a sub-type of physical attacks.
    The further from 0 the number is, the more beneficial the modifier.
    A number lower than 0 heals. */
    protected double bluntResistance = 1;
    public double getBluntResistance()
    {
        return bluntResistance;
    }
    public void setBluntResistance(double bluntResistance)
    {
        this.bluntResistance = bluntResistance;
    }
    
    /* A modifier to how much damage a Creature takes from slash attacks.
    Slash attacks are a sub-type of physical attacks.
    The further from 0 the number is, the more beneficial the modifier.
    A number lower than 0 heals. */
    protected double slashResistance = 1;
    public double getSlashResistance()
    {
        return slashResistance;
    }
    public void setSlashResistance(double slashResistance)
    {
        this.slashResistance = slashResistance;
    }
    
    /* A modifier to how much damage a Creature takes from thrust damage.
    Thrust attacks are a sub-type of physical attacks.
    The further from 0 the number is, the more beneficial the modifier.
    A number lower than 0 heals. */
    protected double thrustResistance = 1;
    public double getThrustResistance()
    {
        return thrustResistance;
    }
    public void setThrustResistance(double thrustResistance)
    {
        this.thrustResistance = thrustResistance;
    }
    
    /* A modifier to how much damage a Creature takes from regular magical attacks.
    The further from 0 the number is, the more beneficial the modifier.
    A number lower than 0 heals. */
    protected double magicResistance = 1;
    public double getMagicResistance()
    {
        return magicResistance;
    }
    public void setMagicResistance(double magicResistance)
    {
        this.magicResistance = magicResistance;
    }
    
    /* A modifier to how much damage a Creature takes from fire attacks.
    Fire attacks are a sub-type of magic attacks.
    The further from 0 the number is, the more beneficial the modifier.
    A number lower than 0 heals. */
    protected double fireResistance = 1;
    public double getFireResistance()
    {
        return fireResistance;
    }
    public void setFireResistance(double fireResistance)
    {
        this.fireResistance = fireResistance;
    }
    
    /* A modifier to how much damage a Creature takes from ice attacks.
    Ice attacks are a sub-type of magic attacks
    The further from 0 the number is, the more beneficial the modifier.
    A number lower than 0 heals. */
    protected double iceResistance = 1;
    public double getIceResistance()
    {
        return iceResistance;
    }
    public void setIceResistance(double iceResistance)
    {
        this.iceResistance = iceResistance;
    }
    
    /* A modifier to how much damage a Creature takes from electric attacks.
    Electric attacks are a sub-type of magic attacks.
    The further from 0 the number is, the more beneficial the modifier.
    A number lower than 0 heals. */
    protected double electricResistance = 1;
    public double getElectricResistance()
    {
        return electricResistance;
    }
    public void setElectricResistance(double electricResistance)
    {
        this.electricResistance = electricResistance;
    }
    
    protected Double[] resistances = 
    {
        physicalResistance, bluntResistance, slashResistance, thrustResistance,
        magicResistance, fireResistance, iceResistance, electricResistance
    };
    public Double[] getResistances()
    {
        return resistances;
    }
    public void setResistanceLevels(double physicalResistance, double bluntResistance, double slashResistance,
            double thrustResistance, double magicResistance, double fireResistance, double iceResistance, double electricResistance)
    {
        setPhysicalResistance(physicalResistance);
        setBluntResistance(bluntResistance);
        setSlashResistance(slashResistance);
        setThrustResistance(thrustResistance);
        setMagicResistance(magicResistance);
        setFireResistance(fireResistance);
        setIceResistance(iceResistance);
        setElectricResistance(electricResistance);
    }
    public void setResistances(Double[] resistances)
    {
        this.resistances = resistances;
    }
    
    // The level of the Creatue which is the same and the dungeon level
    protected int creatureLevel = dungeonLevel;
    public int getCreatureLevel()
    {
        return creatureLevel;
    }
    public void setCreatureLevel()
    {
        this.creatureLevel = dungeonLevel;
    }
    
    // Whether it is a Creature's turn or not. 
    // True = it is their turn, False = it's not their turn.
    protected boolean isMyTurn = false;
    public boolean getIsMyTurn()
    {
        return isMyTurn;
    }
    public void setIsMyTurn(boolean isMyTurn)
    {
        this.isMyTurn = isMyTurn;
    }
    
    // Whether the creature is defending or not
    // True = they are defending, False = they are not defending
    protected boolean isDefending = false;
    public boolean getIsDefending()
    {
        return isDefending;
    }
    public void setIsDefending(boolean isDefending)
    {
        this.isDefending = isDefending;
    }
    
    // How many times a Creature can heal
    protected int healingCharges = 0;
    public int getHealingCharges()
    {
        return healingCharges;
    }
    public void setHealingCharges(int healingCharges)
    {
        this.healingCharges = healingCharges;
    }
    
    protected String creatureType = "";
    public String getCreatureType()
    {
        return creatureType;
    }
    public void setCreatureType(String creatureType)
    {
        this.creatureType = creatureType;
    }
    
    // CONSTRUCTORS
    
    /**
     * Empty Constructor
     */
    public Creature()
    {
        
    }
    
    /**
     * Simple Creature constructor that only has a max health and its current health
     * @param maxHP the maximum health the Creature can have
     * @param currentHP the current health of the Creature
     */
    public Creature(int maxHP, int currentHP)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
    }
    
    /**
     * Slightly more advanced constructor that contains the Creature's max health, current health, strength, and defense
     * @param maxHP the maximum health the Creature can have
     * @param currentHP the current health of the Creature
     * @param str how physically strong the Creature is
     * @param def how physically sturdy the Creature is
     */
    public Creature(int maxHP, int currentHP, int str, int def)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
    }
    
    /**
     * Even more advanced constructor that adds magic and magic defense
     * @param maxHP the maximum amount of health the Creature can have
     * @param currentHP the current health of the Creature
     * @param str how physically strong the Creature is
     * @param def how physically sturdy the Creature is
     * @param magic how magically strong the Creature is
     * @param magicDef how magically sturdy the Creature is
     */
    public Creature(int maxHP, int currentHP, int str, int def, int magic, int magicDef)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
    }
    
    /**
     * Even more advanced constructor that adds speed
     * @param maxHP the maximum amount of health the Creature can have
     * @param currentHP the current health of the Creature
     * @param str how physically strong the Creature is
     * @param def how physically sturdy the Creature is
     * @param magic how magically strong the Creature is
     * @param magicDef how magically sturdy the Creature is
     * @param spd how fast the Creature is
     */
    public Creature(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd)
    {
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
        setSpd(spd);
    }
    
    /**
     * Full Constructor that introduces resistances and a few booleans
     * @param maxHP the maximum amount of health the Creature can have
     * @param currentHP the current health of the Creature
     * @param str how physically strong the Creature is
     * @param def how physically sturdy the Creature is
     * @param magic how magically strong the Creature is
     * @param magicDef how magically sturdy the Creature is
     * @param spd how fast the Creature is
     * @param resistances what damage types the Creature is weak/resistant to
     * @param isMyTurn whether it is the creature's turn or not
     * @param isDefending whether the creature is defending or not
     * @param status the current status of the creature
     * @param healingCharges the number of times the Creature can heal
     * @param creatureType what type of Creature it is
     */
    public Creature(int maxHP, int currentHP, int str, int def, int magic, int magicDef, int spd, Double[] resistances, boolean isMyTurn, boolean isDefending, String status, int healingCharges, String creatureType)
    {
        
        setMaxHP(maxHP);
        setCurrentHP(currentHP);
        setStr(str);
        setDef(def);
        setMagic(magic);
        setMagicDef(magicDef);
        setSpd(spd);
        setResistances(resistances);
        setCreatureLevel();
        setIsMyTurn(isMyTurn);
        setIsDefending(isDefending);
        setStatus(status);
        setHealingCharges(healingCharges);
        setCreatureType(creatureType);
    }
    
    // METHODS
    
    /**
     * Setting up some basics so I don't have to enter them in every class
     * @param target 
     */
    public void attack(Creature target)
    {
        if(this.getStatus().equals("Paralyzed"))
        {
            this.paralysisCheck();
        }
        else if(this.getStatus().equals("Frozen"))
        {
            this.frozenCheck();
        }
    }
    
    /**
     * The Creature defends against the next attack, thereby halving the damage it deals
     * @param attacker the Creature attacking them
     */
    public void defend(Creature attacker)
    {
        if(this.getStatus().equals("Paralyzed"))
        {
            this.paralysisCheck();
        }
        else if(this.getStatus().equals("Frozen"))
        {
            this.frozenCheck();
        }
        if(!this.getIsMyTurn())
        {
            return;
        }
        
        this.setIsDefending(true);
        attacker.checkStatus(this);
        
    }
    
    /**
     * Setting up some basics so I don't have to enter them in every class
     * @param target 
     */
    public void offensiveAbility1(Creature target)
    {
        if(this.getStatus().equals("Paralyzed"))
        {
            this.paralysisCheck();
        }
        else if(this.getStatus().equals("Frozen"))
        {
            this.frozenCheck();
        }
    }
    
    /**
     * Setting up some basics so I don't have to enter them in every class
     * @param target 
     */
    public void offensiveAbility2(Creature target)
    {
        if(this.getStatus().equals("Paralyzed"))
        {
            this.paralysisCheck();
        }
        else if(this.getStatus().equals("Frozen"))
        {
            this.frozenCheck();
        }
    }
    
    /**
     * Setting up some basics so I don't have to enter them in every class
     * @param target 
     */
    public void offensiveAbility3(Creature target)
    {
        if(this.getStatus().equals("Paralyzed"))
        {
            this.paralysisCheck();
        }
        else if(this.getStatus().equals("Frozen"))
        {
            this.frozenCheck();
        }
    }
    
    /**
     * Compares the speeds of two Creatures to decide which goes first
     * @param enemy the enemy of the main Creature
     */
    public void compareSpeed(Creature enemy)
    {
        if(this.getSpd() >= enemy.getSpd())
        {
            this.setIsMyTurn(true);
            enemy.setIsMyTurn(false);
        }
        else
        {
            enemy.setIsMyTurn(true);
            this.setIsMyTurn(false);
        }
    }
    
    /**
     * The damage a Creature takes when it's burned
     */
    public void takeBurnDamage()
    {
        if(this.getStatus().equals("Burned"))
        {
            Random burnDamageCheck = new Random();
        
            double threshold = 0.8;
        
            if(burnDamageCheck.nextDouble() <= threshold)
            {
                int burnDamage = (int)(this.getMaxHP() * 0.0625);
                this.setCurrentHP(this.getCurrentHP() - burnDamage);
            }
        
            double cureChance = 0.15;
        
            if(burnDamageCheck.nextDouble() <= cureChance)
            {
                this.setStatus("Healthy");
            }
        }
    }
    
    /**
     * The damage a Creature takes when it's poisoned
     */
    public void takePoisonDamage()
    {
        if(this.getStatus().equals("Poisoned"))
        {
            Random poisonDamageCheck = new Random();
        
            double threshold = 0.8;
        
            if(poisonDamageCheck.nextDouble() <= threshold)
            {
                int poisonDamage = (int)(this.getMaxHP() * 0.0625);
                this.setCurrentHP(this.getCurrentHP() - poisonDamage);
            }
        
            double cureChance = 0.15;
        
            if(poisonDamageCheck.nextDouble() <= cureChance)
            {
                this.setStatus("Healthy");
            }
        }
    }
    
    /**
     * What to do if the Creature is paralyzed
     */
    public void paralysisCheck()
    {
        if(this.getStatus().equals("Paralyzed"))
        {
            Random doNothingChance = new Random();
            double threshold = 0.5;
        
            if(doNothingChance.nextDouble() <= threshold)
            {
                this.setIsMyTurn(false);
            }
        
            double cureChance = 0.2;
        
            if(doNothingChance.nextDouble() <= cureChance)
            {
                this.setStatus("Healthy");
            }
        }
    }
    
    /**
     * What to do if the Creature is frozen
     */
    public void frozenCheck()
    {
        if(this.getStatus().equals("Frozen"))
        {
            Random doNothingChance = new Random();
            double threshold = 0.8;
        
            if(doNothingChance.nextDouble() <= threshold)
            {
                this.setIsMyTurn(false);
            }
        
            double cureChance = 0.2;
        
            if(doNothingChance.nextDouble() <= cureChance)
            {
                this.setStatus("Healthy");
            }
        }
    }
    
    /**
     * Checks the Creature's status and does the appropriate actions
     */
    public void checkStatus(Creature attacker)
    {
        if(this.getStatus().equals("Burned"))
        {
            this.takeBurnDamage();
        }
        else if(this.getStatus().equals("Poisoned"))
        {
            this.takePoisonDamage();
        }
        
        if(this.getCurrentHP() <= 0)
        {
            this.setStatus("Dead");
            if(this.getCreatureType().equals("Boss"))
            {
                dungeonLevel += 5;
                
            }
            else if(this.getCreatureType().equals("Knight"))
            {
                //What to do when the Hero dies
            }
            else
            {
                dungeonLevel++;
            }
            this.setIsMyTurn(false);
            attacker.setIsMyTurn(false);
            
        }
        else
        {
            attacker.setIsMyTurn(false);
            this.setIsMyTurn(true);
            this.setIsDefending(false);
        }
    }
    
    /**
     * Prints out the resistances of the Creature
     */
    public void printResistances()
    {
        System.out.println("Physical Resistance:\t" + this.getPhysicalResistance() + 
                "\nBlunt Resistance:\t" + this.getBluntResistance() + 
                "\nSlash Resistance:\t" + this.getSlashResistance() +
                "\nThrust Resistance:\t" + this.getThrustResistance() + 
                "\nMagic Resistance:\t" + this.getMagicResistance() + 
                "\nFire Resistance:\t" + this.getFireResistance() + 
                "\nIce Resistance:\t" + this.getIceResistance() + 
                "\nElectric Resistance:\t" + this.getElectricResistance());
    }
    
    /**
     * Prints the stats and status of the Creature
     */
    public void printInfo()
    {
        System.out.println("HP:\t" + this.getCurrentHP() + "/" + this.getMaxHP() + 
                "\nStr:\t" + this.getStr() + "\nDef:\t" + this.getDef() + "\nMagic:\t" + this.getMagic() + 
                "\nMagDef:\t" + this.getMagicDef() + "\nSpd:\t" + this.getSpd() + "\nStatus:\t" + 
                this.getStatus());
    }
}

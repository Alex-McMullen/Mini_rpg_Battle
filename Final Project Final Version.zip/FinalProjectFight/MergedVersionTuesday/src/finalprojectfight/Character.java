package finalprojectfight;

import java.util.Random;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nicho
 */
public class Character{
    
    protected Cell currentCell;
    protected Map map;
    protected boolean goneThroughOneChest = false;
     public Character(Map newMap, int startRow, int startColumn )
    {
        currentCell = null;
        map = newMap;
        map.addCharacter(this, startRow, startColumn);
        

    }


    public void setCell(Cell cc) {
        currentCell = cc;
    }

    public void move(int row, int col) {
        Cell OldCell = currentCell;
        Cell NewCell = map.getCell(OldCell.getRow()+ row, OldCell.getCol() + col);

        if (NewCell.cellType() == "Chest"){
            setCell(NewCell);
            OldCell.removeCharacter();
            NewCell.addCharacter(this); 
            goneThroughOneChest = true;
            
            FinalProjectFight.hero.levelUp();
            
            Random encounterChance = new Random();
            double lizardManChance = 0.2;
            double bossChance = 0.05;
            double determinedChance = encounterChance.nextDouble();
            String[] temp = new String[1];
            
            if(determinedChance <= bossChance)
            {
                FinalProjectFight.enemy = new Boss(1,1,2,3,4,5,6,FinalProjectFight.hi,false,false,"Hi",0,"HI");
                BattleFrame.main(temp);
            }
            else if(determinedChance <= lizardManChance)
            {
                FinalProjectFight.enemy = new LizardMan(1,1,2,3,4,5,6,FinalProjectFight.hi,false,false,"hi",0,"hi");
                BattleFrame.main(temp);
            }
        }
        
        else if (NewCell.cellType() == "Door"){
            if (goneThroughOneChest == true){
                  GameHandler.EnteredDoor(OldCell.getCol());
            }
 
        }
        else if (NewCell.cellType() != "Wall"){
           setCell(NewCell);
        OldCell.removeCharacter();
        NewCell.addCharacter(this); 
        }
        
    }

  
    
    
    
}

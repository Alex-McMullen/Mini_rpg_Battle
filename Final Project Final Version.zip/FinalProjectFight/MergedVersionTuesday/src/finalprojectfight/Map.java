package finalprojectfight;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Random;
/**
 *
 * @author nicho
 */
public class Map{
    public JPanel panel;
    public Character theGuy;
    static String[][] map1 = {
        {"Wall", "Wall", "Wall", "Wall" ,"Wall","Wall", "Wall", "Wall", "Wall" ,"Wall"},
        {"Wall", "Floor", "Floor", "Wall" , "Floor", "Chest", "Floor", "Wall", "Floor","Wall"},
        {"Wall", "Floor", "Floor", "Wall" , "Floor", "Floor", "Floor", "Wall", "Floor", "Wall"},
        {"Wall", "Floor", "Floor", "Floor" , "Wall", "Floor", "Wall", "Floor", "Floor","Wall"},
        {"Door", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Door"},
        {"Wall", "Floor", "Floor", "Floor" , "Wall", "Floor", "Wall", "Floor", "Floor","Wall"},
        {"Wall", "Floor", "Floor", "Wall" , "Floor", "Floor", "Floor", "Wall", "Floor","Wall"},
        {"Wall", "Floor", "Floor", "Wall" , "Floor", "Floor", "Floor", "Walld", "Floor","Wall"},
        {"Wall", "Wall", "Wall", "Wall" ,"Wall", "Wall", "Wall", "Wall", "Wall" ,"Wall"}  
    };
    
    static String[][] map2 = {
        {"Wall", "Wall", "Wall", "Wall" ,"Wall","Wall", "Wall", "Wall", "Wall" ,"Wall"},
        {"Wall", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Wall"},
        {"Wall", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor", "Wall"},
        {"Wall", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Wall"},
        {"Door", "Floor", "Floor", "Floor" , "Chest", "Floor", "Floor", "Floor", "Floor","Door"},
        {"Wall", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Wall"},
        {"Wall", "Floor", "Chest", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Wall"},
        {"Wall", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Wall"},
        {"Wall", "Wall", "Wall", "Wall" ,"Wall", "Wall", "Wall", "Wall", "Wall" ,"Wall"}  
    };
    
  static String[][] map3 = {
        {"Wall", "Wall", "Wall", "Wall" ,"Wall","Wall", "Wall", "Wall", "Wall" ,"Wall"},
        {"Wall", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Wall"},
        {"Wall", "Floor", "Wall", "Floor" , "Floor", "Floor", "Floor", "Wall", "Floor", "Wall"},
        {"Wall", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Wall"},
        {"Door", "Floor", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Floor","Door"},
        {"Wall", "Floor", "Wall", "Floor" , "Floor", "Floor", "Floor", "Wall", "Floor","Wall"},
        {"Wall", "Floor", "Floor", "Wall" , "Wall", "Wall", "Wall", "Floor", "Floor","Wall"},
        {"Wall", "Floor", "Floor", "Floor" , "Chest", "Floor", "Floor", "Floor", "Floor","Wall"},
        {"Wall", "Wall", "Wall", "Wall" ,"Wall", "Wall", "Wall", "Wall", "Wall" ,"Wall"}  
    };
    
  static String[][] map4 = {
        {"Wall", "Wall", "Wall", "Wall" ,"Wall","Wall", "Wall", "Wall", "Wall" ,"Wall"},
        {"Wall", "Wall", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Wall","Wall"},
        {"Wall", "Floor", "Wall", "Floor" , "Floor", "Floor", "Floor", "Wall", "Floor", "Wall"},
        {"Wall", "Floor", "Floor", "Wall" , "Floor", "Floor", "Wall", "Floor", "Floor","Wall"},
        {"Door", "Floor", "Floor", "Floor" , "Chest", "Floor", "Floor", "Floor", "Floor","Door"},
        {"Wall", "Floor", "Floor", "Wall" , "Floor", "Floor", "Wall", "Floor", "Floor","Wall"},
        {"Wall", "Floor", "Wall", "Floor" , "Floor", "Floor", "Floor", "Wall", "Floor","Wall"},
        {"Wall", "Wall", "Floor", "Floor" , "Floor", "Floor", "Floor", "Floor", "Wall","Wall"},
        {"Wall", "Wall", "Wall", "Wall" ,"Wall", "Wall", "Wall", "Wall", "Wall" ,"Wall"}  
    };
  
    public static final  int  NUMBER_OF_ROWS = 9;
    public static final  int  NUMBER_OF_COLUMNS = 10;
    public static final  int  CELL_SIZE= 100;
    public static Cell[][] cells = new Cell[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
    
    String[][] mapWeChose;
    /**
     * makes map and chooses which look.
     * @param map 
     */
    public Map(String[][] map)
    {
        Random randomNum = new Random();
        int randomChoice = randomNum.nextInt(4);
        switch (randomChoice) {
            case 0:
                mapWeChose = map1;
                break;
            case 1:
                mapWeChose = map2;
                break;
            case 2:
                mapWeChose = map3;
                break;
            case 3:
                mapWeChose = map4;
                break;
            default:
                break;
        }
    }
    
    public void initializeMap(int startColumn)
    {

        panel = new JPanel(new GridLayout(NUMBER_OF_ROWS,NUMBER_OF_COLUMNS));
        for(int ii = 0; ii< NUMBER_OF_ROWS; ii++)
        {
            for(int jj = 0; jj<NUMBER_OF_COLUMNS; jj++)
            {
                cells[ii][jj] = new Cell(ii,jj,mapWeChose[ii][jj]);
                panel.add(cells[ii][jj].getButton());
            }
        }
        if (startColumn == 8){
           theGuy = new Character(this, 4, 1);

        }
        else {
           theGuy = new Character(this, 4, 8);

        }
    }
    
    JFrame frame;
    public void showMap()
    {
        frame = new JFrame();
        frame.add(panel);
        frame.pack();//gets rid of any extra space not occupied by the cells in the window
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setFocusable(true);
        frame.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(KeyEvent e){
                if (e.getKeyCode() == KeyEvent.VK_S){
                    theGuy.move(1, 0);
                }
                if (e.getKeyCode() == KeyEvent.VK_W){
                    theGuy.move(-1, 0);
                }
                if (e.getKeyCode() == KeyEvent.VK_A){
                    theGuy.move(0, -1);
                }
                if (e.getKeyCode() == KeyEvent.VK_D){
                    theGuy.move(0, 1);
                } 
                
            }
});
        frame.setVisible(true);
    }
    
    public void addCharacter(Character character, int row, int col)
    {
        theGuy = character;
        Cell cc = cells[row][col];
        cc.addCharacter(character);
        character.setCell(cc);
    }
    
    public Cell getCell(int row, int col)
    {
        return cells[row][col];
    }
    
    public void closeMap(){
        frame.setVisible(false);
    }
        
 
    


   

   
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectfight;

import static finalprojectfight.Map.NUMBER_OF_COLUMNS;
import static finalprojectfight.Map.NUMBER_OF_ROWS;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nicho
 */
public class CellTest {
    
    public CellTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getButton method, of class Cell.
     */
    @Test
    public void testGetButton() {
        System.out.println("getButton");
        JPanel panel = new JPanel(new GridLayout(5,5));
        Cell cell = new Cell(1,1,"Floor");
        Cell instance = cell;
        JButton expResult = cell.getButton();
        JButton result = instance.getButton();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of addCharacter method, of class Cell.
     */
    @Test
    public void testAddCharacter() {
        System.out.println("addCharacter");
        Map map1 = new Map(Map.map1);
        map1.initializeMap(8);
        map1.getCell(2, 2).addCharacter(map1.theGuy);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of removeCharacter method, of class Cell.
     */
    @Test
    public void testRemoveCharacter() {
        System.out.println("removeCharacter");
        Map map1 = new Map(Map.map1);
        map1.initializeMap(8);
        map1.getCell(4, 1).removeCharacter();
        // TODO review the generated test code and remove the default call to fail.
      
    }

    /**
     * Test of getRow method, of class Cell.
     */
    @Test
    public void testGetRow() {
        System.out.println("getRow");
        Cell instance = new Cell(1,1,"Floor");
        int expResult = 1;
        int result = instance.getRow();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of getCol method, of class Cell.
     */
    @Test
    public void testGetCol() {
        System.out.println("getCol");
        Cell instance = new Cell(1,1,"Floor");
        int expResult = 1;
        int result = instance.getCol();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of cellType method, of class Cell.
     */
    @Test
    public void testCellType() {
        System.out.println("cellType");
        Cell instance = new Cell(1,1, "Floor");
        String expResult = "Floor";
        String result = instance.cellType();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}

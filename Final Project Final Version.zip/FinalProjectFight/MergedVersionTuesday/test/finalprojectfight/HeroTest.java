package finalprojectfight;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alex McMullen
 */
public class HeroTest {
    
    public HeroTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * healingAbility
     * Scenario: the hero heals
     * Expected Outcome: nothing as it's a placeholder method for a subclass
     */
    @Test
    public void healingAbility_heroHeals_placeholderMethodForSubclass() 
    {
        System.out.println("healingAbility");
        Creature target = null;
        Hero instance = new Hero();
        instance.healingAbility(target);
        
    }

    /**
     * levelUP
     * Scenario: the hero levels up
     * Expected Outcome: nothing as it's a placeholder method for a subclass
     */
    @Test
    public void levelUp_heroLevelsUp_PlaceholderMethodForSubclass() 
    {
        System.out.println("levelUp");
        Hero instance = new Hero();
        instance.levelUp();
        
    }
    
}

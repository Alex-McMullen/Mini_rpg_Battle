package finalprojectfight;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alex McMullen
 */
public class LizardManTest {
    
    public LizardManTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * attack
     * Scenario: LizardMan with 10 str attacks a creature with 20 def
     * Expected Outcome: the creature loses 25 hp, leaving them with 75
     */
    @Test
    public void attack_tenStrLizardManTwentyDefCreature_creatureLosesTwentyFiveHealth() 
    {
        System.out.println("attack");
        Creature target = new Creature(100,100,10,20,10,10);
        LizardMan instance = new LizardMan(100,100,10,20,10,10);
        instance.setStr(10);
        instance.setIsMyTurn(true);
        instance.attack(target);
        int expectedHP = 75;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility1
     * Scenario: lizardMan with 10 str attacks a creature with 20 def
     * Expected Outcome: the creature loses 40 hp, leaving them with 60
     */
    @Test
    public void offensiveAbility1_tenStrLizardManTwentyDefCreature_creatureLosesFortyHealth() 
    {
        System.out.println("offensiveAbility1");
        Creature target = new Creature(100,100,10,20,10,10);
        LizardMan instance = new LizardMan(100,100,10,20,10,10);
        instance.setStr(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility1(target);
        int expectedHP = 60;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility2
     * Scenario: lizardMan with 10 magic attacks a creature with 20 magic def
     * Expected Outcome: the creature loses 15 hp, leaving them with 85
     */
    @Test
    public void offensiveAbility2_tenMagicLizardManTwentyMagicDefCreature_creatureLosesFifteenHealth() 
    {
        System.out.println("offensiveAbility2");
        Creature target = new Creature(100,100,10,20,10,20);
        LizardMan instance = new LizardMan(100,100,10,20,10,10);
        instance.setMagic(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility2(target);
        int expectedHP = 85;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility3
     * Scenario: lizardMan with 10 str attacks a creature with 20 def
     * Expected Outcome: 90% chance the creature loses 60 hp, leaving them with 40
     */
    @Test
    public void offensiveAbility3_tenStrLizardManTwentyDefCreature_creatureLosesSixtyHealth() 
    {
        System.out.println("offensiveAbility3");
        Creature target = new Creature(100,100,10,20,10,10);
        LizardMan instance = new LizardMan(100,100,10,20,10,10);
        instance.setStr(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility3(target);
        int expectedHP = 40;
        assertEquals(expectedHP, target.getCurrentHP());
    }
    
}

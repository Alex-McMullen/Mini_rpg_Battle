package finalprojectfight;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alex McMullen
 */
public class CreatureTest 
{
    private final ByteArrayOutputStream out = new ByteArrayOutputStream();
    
    private final PrintStream originalOut = System.out;
    
    public CreatureTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    

    /**
     * attack
     * Scenario: the hero attacks the target
     * Expected Outcome: nothing as this is a placeholder method for a subclass
     */
    @Test
    public void attack_attacksEnemy_placeholderForSubclass()
    {
        System.out.println("attack");
        Creature target = null;
        Creature instance = new Creature();
        instance.attack(target);
        
    }

    /**
     * defend
     * Scenario: the creature defends
     * Expected Outcome: the creature's "isDefending" boolean changes to true
     */
    @Test
    public void defend_isDefending_statusChangesToTrue() 
    {
        System.out.println("defend");
        Creature attacker = new Creature();
        Creature instance = new Creature();
        instance.setIsMyTurn(true);
        instance.defend(attacker);
        boolean expectedDefending = true;
        assertEquals(expectedDefending, instance.getIsDefending());
    }

    /**
     * offensiveAbility1
     * Scenario: the hero attacks the target
     * Expected Outcome: nothing as this is a placeholder method for a subclass
     */
    @Test
    public void offensiveAbility1_attacksEnemy_placeholderForSubclass() 
    {
        System.out.println("offensiveAbility1");
        Creature target = null;
        Creature instance = new Creature();
        instance.offensiveAbility1(target);
        
    }

    /**
     * offensiveAbility2
     * Scenario: the hero attacks the target
     * Expected Outcome: nothing as this is a placeholder method for a subclass
     */
    @Test
    public void offensiveAbility2_attacksEnemy_placeholderForSubclass() 
    {
        System.out.println("offensiveAbility2");
        Creature target = null;
        Creature instance = new Creature();
        instance.offensiveAbility2(target);
        
    }

    /**
     * offensiveAbility3
     * Scenario: the hero attacks the target
     * Expected Outcome: nothing as this is a placeholder method for a subclass
     */
    @Test
    public void offensiveAbility3_attacksEnemy_placeholderForSubclass() 
    {
        System.out.println("offensiveAbility3");
        Creature target = null;
        Creature instance = new Creature();
        instance.offensiveAbility3(target);
        
    }

    /**
     * compareSpeed
     * Scenario: both the hero and enemy have the same speed
     * Expected Outcome: the hero goes first, i.e. hero.isMyTurn = true
     */
    @Test
    public void compareSpeed_sameSpeed_heroGoesFirst() 
    {
        System.out.println("compareSpeed");
        Creature enemy = new Creature();
        Creature hero = new Creature();
        hero.compareSpeed(enemy);
        boolean expectedTurn = true;
        assertEquals(expectedTurn, hero.getIsMyTurn());
    }

    /**
     * takeBurnDamage
     * Scenario: creature is burned
     * Expected Outcome: creature takes 1/16th of max hp (1 hp) as damage sometimes
     */
    @Test
    public void takeBurnDamage_isBurned_possiblyTakeDamage() 
    {
        System.out.println("takeBurnDamage");
        Creature instance = new Creature(16,16);
        instance.setStatus("Burned");
        instance.takeBurnDamage();// This method is based off of a random number generator so will only pass 80% of the time
        int expectedHP = 15;
        assertEquals(expectedHP, instance.getCurrentHP());
    }

    /**
     * takePoisonDamage
     * Scenario: creature is poisoned
     * Expected Outcome: the creature loses 1/16th of its max hp (1 hp) sometimes
     */
    @Test
    public void takePoisonDamage_isPoisoned_takesOneDamage() 
    {
        System.out.println("takePoisonDamage");
        Creature instance = new Creature(16,16);
        instance.setStatus("Poisoned");
        instance.takePoisonDamage(); //Method is based on a random number generator so will only pass 80% of the time
        int expectedHP = 15;
        assertEquals(expectedHP, instance.getCurrentHP());
        
    }

    /**
     * paralysisCheck
     * Scenario: the creature is not paralyzed
     * Expected Outcome: nothing happens
     */
    @Test
    public void testParalysisCheck() {
        System.out.println("paralysisCheck");
        Creature instance = new Creature();
        instance.paralysisCheck();
        String expectedStatus = "";
        assertEquals(expectedStatus, instance.getStatus());
    }

    /**
     * frozenCheck
     * Scenario: the creature is not frozen
     * Expected Outcome: nothing happens
     */
    @Test
    public void frozenCheck_notFrozen_nothingHappens() 
    {
        System.out.println("frozenCheck");
        Creature instance = new Creature();
        instance.frozenCheck();
        String expectedStatus = "";
        assertEquals(expectedStatus, instance.getStatus());
    }

    /**
     * checkStatus
     * Scenario: the attacker killed the target
     * Expected Outcome: the target's status changes to "Dead"
     */
    @Test
    public void checkStatus_attackerKillsTarget_targetStatusNowDead() 
    {
        System.out.println("checkStatus");
        Creature attacker = new Creature();
        Creature target = new Creature();
        target.checkStatus(attacker);
        String expectedResult = "Dead";
        assertEquals(expectedResult, target.getStatus());
    }

    /**
     * printResistances
     * Scenario: empty constructor
     * Expected Outcome: default resistances (1.0)
     */
    @Test
    public void printResistances_emptyConstructor_defaultResistances() 
    {
        System.out.println("printResistances");
        Creature instance = new Creature();
        
        System.setOut(new PrintStream(out));
        
        instance.printResistances();
        String expectedResult = "Physical Resistance:\t1.0\nBlunt Resistance:\t1.0\n"
                + "Slash Resistance:\t1.0\nThrust Resistance:\t1.0\nMagic Resistance:\t1.0\n"
                + "Fire Resistance:\t1.0\nIce Resistance:\t1.0\nElectric Resistance:\t1.0";
        assertEquals(expectedResult.trim(), out.toString().trim());
        
        System.setOut(originalOut);
    }

    /**
     * printInfo
     * Scenario: empty constructor
     * Expected Outcome: default numbers (zeros)
     */
    @Test
    public void printInfo_emptyConstructor_defaultNumbers() 
    {
        System.out.println("printInfo");
        Creature instance = new Creature();
        
        System.setOut(new PrintStream(out));
        
        String expectedResult = "HP:\t0/0\nStr:\t0\nDef:\t0\nMagic:\t0\nMagDef:\t0\nSpd:\t0\nStatus:\t";
        instance.printInfo();
        assertEquals(expectedResult.trim(), out.toString().trim());
        
        System.setOut(originalOut);
    }
    
}

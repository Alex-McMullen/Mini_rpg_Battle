/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectfight;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nicho
 */
public class MapTest {
        public static Map map1;

    public MapTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of initializeMap method, of class Map.
     */
    @Test
    public void testInitializeMap() {
        System.out.println("initializeMap");
        int startColumn = 1;
        Map instance = new Map(Map.map1);
        instance.initializeMap(startColumn);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of showMap method, of class Map.
     */
    @Test
    public void testShowMap() {
        
        System.out.println("showMap");
        Map instance = new Map(Map.map1);
        instance.initializeMap(1);
        instance.showMap();
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of addCharacter method, of class Map.
     */
    @Test
    public void testAddCharacter() {
        System.out.println("addCharacter");    
        int row = 1;
        int col = 1;
        Map instance = new Map(Map.map1);
        instance.initializeMap(1);
        instance.showMap();
        Character character = new Character(instance, 4, 1);
        instance.addCharacter(character, row, col);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of getCell method, of class Map.
     */
    @Test
    public void testGetCell() {
        System.out.println("getCell");
        int row = 4;
        int col = 8;
        Map instance = new Map(Map.map1);
        instance.initializeMap(1);
        Cell expResult = instance.getCell(4, 8);
        Cell result = instance.getCell(row, col);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of closeMap method, of class Map.
     */
    @Test
    public void testCloseMap() {
        System.out.println("closeMap");
        Map instance = new Map(Map.map1);
        instance.initializeMap(1);
        instance.showMap();
        instance.closeMap();
        // TODO review the generated test code and remove the default call to fail.
    }
    
}

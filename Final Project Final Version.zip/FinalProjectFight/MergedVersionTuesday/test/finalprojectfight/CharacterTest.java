/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalprojectfight;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nicho
 */
public class CharacterTest {
    
    public CharacterTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setCell method, of class Character.
     */
    @Test
    public void testSetCell() {
        System.out.println("setCell");
        Map instance = new Map(Map.map1);
        instance.initializeMap(1);
        Cell cc = instance.getCell(4, 4);
        Character character = instance.theGuy;
        character.setCell(cc);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of move method, of class Character.
     */
    @Test
    public void testMove() {
        System.out.println("move");
        Map ourMap = new Map(Map.map1);
        ourMap.initializeMap(1);

        int row = 0;
        int col = -1;
        ourMap.theGuy.move(row, col);
        // TODO review the generated test code and remove the default call to fail.
    }
    
}

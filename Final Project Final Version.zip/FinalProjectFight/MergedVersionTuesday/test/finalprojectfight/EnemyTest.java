package finalprojectfight;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alex McMullen
 */
public class EnemyTest {
    
    public EnemyTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * takeTurn
     * Scenario: the enemy takes their turn
     * Expected Outcome: the enemy's isMyTurn value changes to false
     */
    @Test
    public void takeTurn_enemyTakesTheirTurn_enemyIsMyTurnChangesToFalse() 
    {
        System.out.println("takeTurn");
        Creature target = new Creature(16,16,16,16,16,16);
        Enemy instance = new LizardMan(16,16,16,16,16,16);
        instance.setIsMyTurn(true);
        instance.takeTurn(target);
        boolean expectedTurn = false;
        assertEquals(expectedTurn, instance.getIsMyTurn());
        
    }

    /**
     * enemyCheck
     * Scenario: the enemy is still alive
     * Expected Outcome: nothing happens
     */
    @Test
    public void testEnemyCheck() 
    {
        System.out.println("enemyCheck");
        Hero attacker = new Hero();
        Enemy instance = new Enemy();
        instance.setStatus("Healthy");
        instance.enemyCheck(attacker);
        String expectedStatus = "Healthy";
        assertEquals(expectedStatus, instance.getStatus());
    }
    
}

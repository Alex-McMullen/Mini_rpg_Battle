package finalprojectfight;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alex McMullen
 */
public class BossTest {
    
    public BossTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * attack
     * Scenario: boss with 10 str attacks a creature with 20 def
     * Expected Outcome: the creature loses 30 hp, leaving them with 70
     */
    @Test
    public void attack_tenStrBossTwentyDefCreature_creatureLosesThirtyHealth() 
    {
        System.out.println("attack");
        Hero target = new Hero(100,100,10,20,10,20);
        Boss instance = new Boss(100,100,10,20,10,20);
        instance.setStr(10);
        instance.setMagic(10);
        instance.setIsMyTurn(true);
        instance.attack(target);
        int expectedHP = 70;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility1
     * Scenario: boss with 10 magic attacks a creature with 20 magic def
     * Expected Outcome: the creature loses 40 hp, leaving them with 60
     */
    @Test
    public void offensiveAbility1_tenMagicBossTwentyMagicDefCreature_creatureLosesFortyHealth() 
    {
        System.out.println("offensiveAbility1");
        Hero target = new Hero(100,100,10,20,10,20);
        Boss instance = new Boss(100,100,10,20,10,20);
        instance.setStr(10);
        instance.setMagic(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility1(target);
        int expectedHP = 60;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility2
     * Scenario: boss with 10 magic attacks a creature with 20 magic def
     * Expected Outcome: the creature loses 35 hp, leaving them with 65
     */
    @Test
    public void offensiveAbility2_tenMagicBossTwentyMagicDefCreature_creatureLosesThirtyFiveHealth() 
    {
        System.out.println("offensiveAbility2");
        Hero target = new Hero(100,100,10,20,10,20);
        Boss instance = new Boss(100,100,10,20,10,20);
        instance.setStr(10);
        instance.setMagic(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility2(target);
        int expectedHP = 65;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility3
     * Scenario: boss with 10 str attacks a creature with 20 def
     * Expected Outcome: the creature has a 90% chance of losing 60 hp, leaving them with 40
     */
    @Test
    public void offensiveAbility3_tenStrBossTwentyDefCreature_creatureLosesSixtyHealth() 
    {
        System.out.println("offensiveAbility3");
        Hero target = new Hero(100,100,10,20,10,20);
        Boss instance = new Boss(100,100,10,20,10,20);
        instance.setStr(10);
        instance.setMagic(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility3(target);
        int expectedHP = 40;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * bossCheck
     * Scenario: the Knight killed the Boss and will level up
     * Expected Outcome: the Knight will level up and gain 50 max hp
     */
    @Test
    public void bossCheck_knightKilledBoss_knightGainFiftyMaxHealth() 
    {
        System.out.println("bossCheck");
        Knight attacker = new Knight();
        Boss instance = new Boss();
        attacker.setMaxHP(100);
        instance.setStatus("Dead");
        instance.bossCheck(attacker);
        int expectedMaxHP = 150;
        assertEquals(expectedMaxHP, attacker.getMaxHP());
    }
    
}

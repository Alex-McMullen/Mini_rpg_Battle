package finalprojectfight;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Alex McMullen
 */
public class KnightTest {
    
    public KnightTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * attack
     * Scenario: the knight with str of 10 attacks an enemy with def of 20
     * Expected Outcome: the enemy loses 25 hp, leaving them with 75
     */
    @Test
    public void attack_tenStrKnightTwentyDefTarget_TargetLosesTwentyFiveHealth() 
    {
        System.out.println("attack");
        Creature target = new Creature(100,100,10,20,10,10);
        Knight instance = new Knight(100,100,10,20,10,10);
        instance.setStr(10);
        instance.setIsMyTurn(true);
        instance.attack(target);
        int expectedHP = 75;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility1
     * Scenario: Knight with str of 10 attacks a creature with def of 20
     * Expected Outcome: the creature loses either 10,20,30,40, or 50 hp, depending on the number of hits
     */
    @Test
    public void offensiveAbility1_tenStrKnightTwentyDefCreature_creatureLosesBetweenTenAndFiftyHealth() //Method is dependent on a Random Number Generator, meaning the test will only pass about 20% of the time
    {
        System.out.println("offensiveAbility1");
        Creature target = new Creature(100,100,10,20,10,10);
        Knight instance = new Knight(100,100,10,20,10,10);
        instance.setStr(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility1(target);
        int expectedHP = 90;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility2
     * Scenario: Knight with 10 str attacks a creature with 20 def
     * Expected Outcome: the creature loses 40 hp, leaving them with 60
     */
    @Test
    public void offensiveAbility2_tenStrKnightTwentyDefCreature_creatureLosesFortyHealth() 
    {
        System.out.println("offensiveAbility2");
        Creature target = new Creature(100,100,10,20,10,10);
        Knight instance = new Knight(100,100,10,20,10,10);
        instance.setStr(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility2(target);
        int expectedHP = 60;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * offensiveAbility3
     * Scenario: Knight with 10 str attacks a creature with 20 def
     * Expected Outcome: the creature loses between 25 and 60 hp
     */
    @Test
    public void offensiveAbility3_tenStrKnightTwentyDefCreature_creatureLosesBetweenTwentyFiveAndSixtyHealth() 
    // this method is based off of a random number generator with a range of 70, but the actual
            //value should always be between 40 and 75
    {
        System.out.println("offensiveAbility3");
        Creature target = new Creature(100,100,10,20,10,10);
        Knight instance = new Knight(100,100,10,20,10,10);
        instance.setStr(10);
        instance.setIsMyTurn(true);
        instance.offensiveAbility3(target);
        int expectedHP = 60;
        assertEquals(expectedHP, target.getCurrentHP());
    }

    /**
     * healingAbility
     * Scenario: the Knight is at 60/100 hp and is going to heal
     * Expected Outcome: the Knight heals to 100/100 hp
     */
    @Test
    public void healingAbility_knightMissingFortyHealth_knightHealsToFull() 
    {
        System.out.println("healingAbility");
        Creature target = new Creature();
        Knight instance = new Knight();
        instance.setCurrentHP(60);
        instance.setMaxHP(100);
        instance.setIsMyTurn(true);
        instance.healingAbility(target);
        int expectedHP = 100;
        assertEquals(expectedHP, instance.getCurrentHP());
    }

    /**
     * levelUp
     * Scenario: the Knight has 100 maxHP and levels up
     * Expected Outcome: the Knight now has 150 maxHP
     */
    @Test
    public void levelUp_oneHundredMaxHp_oneFiftyMaxHp() 
    {
        System.out.println("levelUp");
        Knight instance = new Knight();
        instance.setMaxHP(100);
        instance.levelUp();
        int expectedMaxHP = 150;
        assertEquals(expectedMaxHP, instance.getMaxHP());
    }
    
}
